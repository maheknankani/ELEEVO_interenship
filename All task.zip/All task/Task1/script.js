document.addEventListener('DOMContentLoaded', function () {
    const toggleBtn = document.getElementById('sidebar-toggle');
    const sidebar = document.getElementById('sidebar');
    const links = document.querySelectorAll('.sidebar-links li');
    const mainContent = document.getElementById('main-content');

    // Sidebar toggle
    toggleBtn.addEventListener('click', function () {
        sidebar.classList.toggle('collapsed');
    });

    // Simple page content for each section
    const pages = {
        home: `<h1>Welcome!</h1><p>This is your main content area.</p>`,
        search: `<h1>Search</h1><p>Search for your files and content here.</p>`,
        files: `<h1>Files</h1><p>Here are your files. (You can list files here.)</p>`,
        settings: `<h1>Settings</h1><p>Adjust your preferences here.</p>`,
        help: `<h1>Help</h1><p>How can we help you?</p>`
    };

    // Navigation logic
    links.forEach(link => {
        link.addEventListener('click', function () {
            // Remove active from all
            links.forEach(l => l.classList.remove('active'));
            // Set active
            this.classList.add('active');
            // Load content
            const page = this.getAttribute('data-page');
            mainContent.innerHTML = pages[page] || `<h1>Page not found</h1>`;
        });
    });

    // Set Home as default active
    links[0].classList.add('active');
});