const toggleBtn = document.getElementById('theme-toggle');
const body = document.body;

// Set theme on load
function setTheme(theme) {
  if (theme === 'dark') {
    body.classList.add('dark');
    toggleBtn.innerHTML = '<i class="fa-solid fa-sun"></i> Light';
  } else {
    body.classList.remove('dark');
    toggleBtn.innerHTML = '<i class="fa-solid fa-moon"></i> Dark';
  }
}

const savedTheme = localStorage.getItem('theme') || 'light';
setTheme(savedTheme);

toggleBtn.addEventListener('click', () => {
  const isDark = body.classList.toggle('dark');
  const theme = isDark ? 'dark' : 'light';
  setTheme(theme);
  localStorage.setItem('theme', theme);
});

// Mobile nav toggle
const navToggle = document.querySelector('.nav-toggle');
const mainNav = document.querySelector('.main-nav');
navToggle.addEventListener('click', () => {
  mainNav.classList.toggle('open');
});

// Close nav on link click (mobile)
document.querySelectorAll('.main-nav a').forEach(link => {
  link.addEventListener('click', () => {
    mainNav.classList.remove('open');
  });
});

// Smooth scroll for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function(e) {
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      e.preventDefault();
      target.scrollIntoView({ behavior: 'smooth' });
    }
  });
});

// Section fade-in animation on scroll
const fadeEls = document.querySelectorAll('.fade-in');
const fadeInOnScroll = () => {
  fadeEls.forEach(el => {
    const rect = el.getBoundingClientRect();
    if (rect.top < window.innerHeight - 80) {
      el.classList.add('visible');
    }
  });
};
window.addEventListener('scroll', fadeInOnScroll);
window.addEventListener('load', fadeInOnScroll);